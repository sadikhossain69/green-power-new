const BigImage = () => {
    return (
        <>
            <section className="container mx-auto">
                <div className="py-5 flex justify-center">
                    <img className="lg:w-[65%] w-full" src="bigImage.jpg" alt="" />
                </div>
            </section>
        </>
    );
};

export default BigImage;